#!/bin/bash

export PYTHONPATH=$PWD
cd binary/user_ui
python main.py
